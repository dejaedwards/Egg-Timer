for index in 1...6 {
    print ("\(index) times 30 is \(index * 30)")
}

//when timer stops
var eggTimer = 180

if eggTimer == 180 {
    print("Egg Timer Stopped")
} else {
    print("Egg Timer is on")
}
